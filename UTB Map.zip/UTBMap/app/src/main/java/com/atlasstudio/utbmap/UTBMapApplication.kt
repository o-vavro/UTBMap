package com.atlasstudio.utbmap

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class UTBMapApplication: Application() {
}