package com.atlasstudio.utbmap.utils

val <T> T.exhaustive: T
    get() = this